#!/usr/bin/python3
import time

while (1):
	time.sleep(10)